<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CR12_Max_Strauss_traveler
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area" style="max-width: 20%; float:right; margin-top:2%; margin-bottom:2%; padding:2%; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 0px 5px 0 rgba(0, 0, 0, 0.5);">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>


<!-- #secondary -->
