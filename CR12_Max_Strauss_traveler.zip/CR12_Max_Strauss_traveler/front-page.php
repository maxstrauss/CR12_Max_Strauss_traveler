<?php get_header(); ?>
<br>
<br>
<div class="container">

<div class="row">
  <div class="col-md-8 mb-5">
    <h2>Mount Everest</h2>
    <hr>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A deserunt neque tempore recusandae animi soluta quasi? Asperiores rem dolore eaque vel, porro, soluta unde debitis aliquam laboriosam. Repellat explicabo, maiores!</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis optio neque consectetur consequatur magni in nisi, natus beatae quidem quam odit commodi ducimus totam eum, alias, adipisci nesciunt voluptate. Voluptatum.</p>
    <a class="btn btn-primary btn-lg" href="wordpress/blog/">Check out our Blog</a>
  </div>
  <div class="col-md-4 mb-5">
    <h2>Contact Us</h2>
    <hr>
    <address>
      <strong>Mount Everest travel agency</strong>
      <br>Mount Everest
      <br>Sagarmatha National Park 00977 Nepal
      <br>00977 Nepal
      <br>
    </address>
    <address>
      <abbr title="Phone">Phone:</abbr>
      (123) 456-7890
      <br>
      <abbr title="Email">Email:</abbr>
      <a href="mailto:#">name@example.com</a>
    </address>
  </div>
</div>

</div>

<?php get_footer(); ?>